### Hexlet tests and linter status:
[![Actions Status](https://github.com/nic11371/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/nic11371/python-project-49/actions)
<a href="https://codeclimate.com/github/nic11371/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2baa4e2e5ed6a24bc653/maintainability" /></a>
<a href="https://asciinema.org/a/664214" target="_blank"><img src="https://asciinema.org/a/664214.svg" /></a>
https://semver.org/lang/ru/
<a href="https://asciinema.org/a/664540" target="_blank"><img src="https://asciinema.org/a/664540.svg" /></a>
<a href="https://asciinema.org/a/664559" target="_blank"><img src="https://asciinema.org/a/664559.svg" /></a>
<a href="https://asciinema.org/a/664588" target="_blank"><img src="https://asciinema.org/a/664588.svg" /></a>