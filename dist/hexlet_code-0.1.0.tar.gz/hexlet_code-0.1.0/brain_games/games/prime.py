from random import randint


def logic_function():
    number = randint(1, 100)
    current_answer = ""
    if number <= 1:
        current_answer = "no"
    if number == 2:
        current_answer = "yes"
    if number % 2 == 0:
        current_answer = "no"
    for i in range(2, int(number // 2) + 1):
        if number % i == 0:
            current_answer = "no"
        else:
            current_answer = "yes"
    return (number, current_answer)
